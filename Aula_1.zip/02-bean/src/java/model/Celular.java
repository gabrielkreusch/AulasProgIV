package model;

pulic class Celular {

	private String modelo;
	private int memoria;
	private String operadora;

	public Celular(){

	}

	public String getModelo(){
		return this.modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public int getMemoria(){
		return this.memoria;
	}

	public void setMemoria(int memoria){
		this.memoria = memoria
	}

	public String getOperadora(){
		return this.operadora;
	}

	public void setOperadora(String operadora){
		this.operadora = operadora;
	}
}